@brief 		Hide Wifi Networks
@details 	x
@auth		Justin Reina
@date		9/14/24
	

@section 	Notes
	x

