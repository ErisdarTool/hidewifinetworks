@brief 		Hide WiFi Networks
@details 	Takes a few iterations for congested areas
@auth 		Justin Reina
@date 		4/28/24


@section 	Notes


	//List all visible networks
	
	netsh wlan show networks > somefile.txt
	
	//Hide a network (Cmd Admin)
	
	netsh wlan add filter permission=block ssid="WIFI_NAME" networktype=infrastructure

	netsh wlan add filter permission=block ssid="
	" networktype=infrastructure

